// ==UserScript==
// @name        KERAN.CO | Claim Faucet
// @namespace   auto.claim.faucet
// @description https://keran.co/?ref=35176
// @author      MrBug
// @version     0.1
// @icon        https://www.google.com/s2/favicons?sz=64&domain=keran.co
// @grant       window.close
// @antifeature referal-link
// @license     Copyright MrBug
// @match       https://keran.co/*
// @downloadURL https://update.greasyfork.org/scripts/480402/KERANCO%20%7C%20Claim%20Faucet.user.js
// @updateURL https://update.greasyfork.org/scripts/480402/KERANCO%20%7C%20Claim%20Faucet.meta.js
// ==/UserScript==
/*

███╗   ███╗██████╗    ██████╗ ██╗   ██╗ ██████╗     ███████╗ █████╗ ██╗   ██╗ ██████╗███████╗████████╗    ███████╗ ██████╗██████╗ ██╗██████╗ ████████╗
████╗ ████║██╔══██╗   ██╔══██╗██║   ██║██╔════╝     ██╔════╝██╔══██╗██║   ██║██╔════╝██╔════╝╚══██╔══╝    ██╔════╝██╔════╝██╔══██╗██║██╔══██╗╚══██╔══╝
██╔████╔██║██████╔╝   ██████╔╝██║   ██║██║  ███╗    █████╗  ███████║██║   ██║██║     █████╗     ██║       ███████╗██║     ██████╔╝██║██████╔╝   ██║
██║╚██╔╝██║██╔══██╗   ██╔══██╗██║   ██║██║   ██║    ██╔══╝  ██╔══██║██║   ██║██║     ██╔══╝     ██║       ╚════██║██║     ██╔══██╗██║██╔═══╝    ██║
██║ ╚═╝ ██║██║  ██║██╗██████╔╝╚██████╔╝╚██████╔╝    ██║     ██║  ██║╚██████╔╝╚██████╗███████╗   ██║       ███████║╚██████╗██║  ██║██║██║        ██║
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═════╝  ╚═════╝  ╚═════╝     ╚═╝     ╚═╝  ╚═╝ ╚═════╝  ╚═════╝╚══════╝   ╚═╝       ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝

*/

(function(){
    'use strict';

    var email = 'seuemail@gmail.com'; // Type here your e-mail address
    var intervalclaim = 10 // Don't change it

    function onDocumentReady(fn) {
        if (document.readyState != "loading") {
            fn();
        } else {
            document.addEventListener("DOMContentLoaded", fn);
        }
    }

    onDocumentReady(function(){

        let check_address = 'https://keran.co';
        function isCaptchaChecked() {
            return (
                (grecaptcha && grecaptcha.getResponse().length > 0)
            );
        }


        let login = setInterval (function(){
            let card_md = document.querySelector("#myModal.is-active")
            let emailfield = document.querySelector("input[type='email']")
            let button = document.querySelector("button[type='submit']")
            if(card_md && emailfield && emailfield.value !== email){
                emailfield.value = email;
            }
            if(emailfield.value == email && isCaptchaChecked()){
                button.click();
                clearInterval(login);
            }
        },5000)

        if(window.location.href.includes('captha')){
            let claim = setInterval(function (){
                let button = document.querySelector("button[data-target='#myModal']:not([disabled])")
                let button2 = document.querySelector("button[type='submit']")
                if(button){
                    button.click();
                }
                if(button2 && isCaptchaChecked()){
                    setTimeout(function() { window.location.reload() }, 50000)
                    button2.click();
                    clearInterval(claim);
                }

            },5000)

            let claim2 = setInterval(function (){
                let turnstile = document.querySelector("input[name='cf-turnstile-response']")
                let button = document.querySelector("button[data-target='#myModal']:not([disabled])")
                let button2 = document.querySelector("button[type='submit']")
                if(button){
                    button.click();
                }
                if(button2 && turnstile && turnstile.value.length > 0){
                    setTimeout(function() { window.location.reload() }, 60000)
                    button2.click();
                    clearInterval(claim2);
                }

            },5000)
        }

        if(window.location.href.includes('faucet')){
            setTimeout(function(){
                let button = document.querySelector("button[type='submit']:not([disabled])")
                if(button){
                    button.click();
                }
                setTimeout(function(){window.location.reload()},60000)
            },5000)
            setTimeout(function refresh() {
                window.location.reload()
            }, intervalclaim*60000 + Math.floor(Math.random()*60000) + 20000)
        }

        if(window.location.href.includes('dashboard')){
            setTimeout(function(){
                location.href= 'faucet.php'
            },5000)
        }

        if(window.location.href == (check_address) || window.location.href == (check_address + '/') || window.location.href == (check_address + '/index.php')){
            setTimeout(function(){
                if(location.search !== '?ref=35176'){
                    location.search = '?ref=35176'
                }
            },2000)
        }

        if(location.search == '?ref=35176'){
            setTimeout(function(){
                let button = document.querySelector('button[data-target="#myModal"]');
                if(button){
                    button.click();
                }
                setTimeout(function(){window.location.reload()},60000)
            },3000)
        }

        setTimeout(function(){
            let alertMsg = document.querySelector("div.message-body")
            if(alertMsg && alertMsg.innerText.includes("was sent")){
                location.reload()
            }
        },5000)

    });


})();