// ==UserScript==
// @name         CloudFlare Turnstile
// @namespace    CloudFlare Turnstile
// @version      0.3
// @description  Solves CloudFlare Turnstile
// @author       steamfaucet
// @match        https://challenges.cloudflare.com/*
// @grant        none
// @license     GPL-3.0-or-later; https://www.gnu.org/licenses/gpl-3.0.txt

// ==/UserScript==

(function () {
  'use strict';

  setInterval(function () {
    document.querySelector('#challenge-stage')?.querySelectorAll('*')?.forEach(element => {
      element.click();
    });
  }, 3000);

})();
