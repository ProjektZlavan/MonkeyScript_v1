// ==UserScript==
// @name         REDIRECIONAMENTO V.4
// @namespace    https://keran.co/
// @version      1.0
// @description  Redireciona para o dashboard se o endereço não começar com "https://keran.co/" e verifica o reCAPTCHA
// @author       Seu Nome
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const dominioDesejado = "keran.co"; // Domínio base desejado
    const email = 'seuemail@gmail.com'; // Seu endereço de e-mail

    function isCaptchaChecked() {
        return (
            (grecaptcha && grecaptcha.getResponse().length > 0)
        );
    }

    function verificarEndereco() {
        const dominioAtual = window.top.location.hostname; // Verifica apenas na janela pai
        if (dominioAtual !== dominioDesejado) {
            // Redireciona apenas na janela pai
            window.top.location.href = "https://keran.co/faucet.php";
        }
    }

    function login() {
        // Lógica de login (mantida como está)
    }

    // Executa a verificação de endereço a cada 5 minutos
    setInterval(verificarEndereco, 30000); // 300000 ms = 5 minutos

    // Outras funções e lógica conforme necessário

})();