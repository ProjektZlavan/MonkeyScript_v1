// ==UserScript==
// @name         IconCaptcha Faucets Rotator
// @namespace    IconCaptcha Faucets Rotator
// @version      0.8
// @description  Script to claim faucets
// @author       steamfaucet
// @match        https://get-bitcoin.net/*
// @match        https://claimbits.net/*
// @match        https://getdoge.io/*
// @match        https://earnbitmoon.club/*
// @match        https://dogebits.net/*
// @match        https://qashbits.com/*
// @match        https://bitdaddy.cash/*
// @match        https://funcryptofaucet.com/*
// @match        https://coinadster.com/*
// @match        https://rushbitcoin.com/*
// @match        https://claimfreecoins.cc/*
// @match        https://bitcointricks.com/*
// @match        https://macrobits.io/*
// @match        https://cashmine.online*
// @match        https://cashmine.online/*
// @match        https://best-shopme.com/*
// @match        https://nevcoins.club/*
// @match        https://faucetsfly.com/*
// @match        https://sports4dbtc.com/*
// @match        https://ptchub.xyz/*
// @match        https://ltchunt.com/*
// @match        https://vsl.one/*
// @match        https://topadcoin.com/*
// @match        https://probux.org/*
// @match        https://nevcoins.club/*
// @match        https://grab.tc/*
// @match        https://claimlite.club/*
// @match        https://sumfaucet.com/*
// @match        https://claimfreebits.com/*
// @match        https://bitcaps.io/*
// @match        https://faucetofbob.xyz/*
// @match        https://likeafaucet.com/*
// @match        https://faucetgigs.com/*
// @match        https://btccanyon.com/*
// @connect      claimbits.net
// @connect      get-bitcoin.net
// @connect      getdoge.io
// @connect      faucetbeast.com
// @connect      earnbitmoon.club
// @connect      dogebits.net
// @connect      presearch.com
// @connect      qashbits.com
// @connect      bitdaddy.cash
// @connect      claimbit.com
// @connect      funcryptofaucet.com
// @connect      coinadster.com
// @connect      rushbitcoin.com
// @connect      claimfreecoins.cc
// @connect      bitcointricks.com
// @connect      macrobits.io
// @connect      cashmine.online
// @connect      best-shopme.com
// @connect      adsatosh.com
// @connect      adfaucetpay.com
// @connect      adcrypto.co.in
// @connect      btcadspace.com
// @connect      earncrypto.in
// @connect      nevcoins.club
// @connect      faucetsfly.com
// @connect      sports4dbtc.com
// @connect      ptchub.xyz
// @connect      ltchunt.com
// @connect      probux.org
// @connect      topadcoin.com
// @connect      grab.tc
// @connect      claimlite.club
// @connect      sumfaucet.com
// @connect      claimfreebits.com
// @connect      bitcaps.io
// @connect      faucetofbob.xyz
// @connect      vsl.one
// @connect      likeafaucet.com
// @connect      faucetgigs.com
// @connect      btccanyon.com
// @license      GPL-3.0-or-later; https://www.gnu.org/licenses/gpl-3.0.txt
// @noframes
// @grant        GM_addStyle
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest


// ==/UserScript==
(function() {
    'use strict';

    // Instructions:
    // 1. Visit the website and register https://shortlinksfaucet.xyz/?p=iconfaucets
    // 2. Add your username and password below
    // 3. The following are the solvers required
    // a.) Recaptcha Solver b.)Hcaptcha Solver c.) Icon Captcha Solver d.)Shortlinks Script e. AutoClose Windows Script
    // 4. Change the config below according to your needs
    // Note: The solver will stop if any shortlink has problem, so update the list accordingly below.
    // You can manually navigate the pages by enabling ENABLE_NEXT_BUTTON below.

    // Change the value to false if you wish to disable shortlinks based on captcha type
    const ENABLE_SHORTLINKS_HCAPTCHA = true;
    const ENABLE_SHORTLINKS_RECAPTCHA = true;

    // Enable next button if you wish to manually navigate the page.
    const ENABLE_NEXT_BUTTON = false;

    //List of the faucet websites
    //Comment the lines of url if you don't use them
    var websiteData = [

        {url : "https://get-bitcoin.net/faucet.html", login: "", password: "", regex: "faucet.html"},
        {url : "https://get-bitcoin.net/read.html", login: "", password: "", regex: "read.html"},
        {url : "https://get-bitcoin.net/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},

        {url : "https://dogebits.net/faucet.html",login: "", password: "", regex: "faucet.html"},
        {url : "https://dogebits.net/read.html", login: "", password: "", regex: "read.html"},
        {url : "https://dogebits.net/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},

        {url : "https://claimbits.net/faucet.html", login: "", password: "", regex: "faucet.html"},
        {url : "https://claimbits.net/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://claimbits.net/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://ltchunt.com/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://ltchunt.com/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://earnbitmoon.club/", login: "", password: ""},
        {url : "https://earnbitmoon.club/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://earnbitmoon.club/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://bitcaps.io/", login: "", password: ""},
        {url : "https://bitcaps.io/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://bitcaps.io/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://sumfaucet.com/roll.html", login: "", password: "",regex: "roll.html"},
        {url : "https://sumfaucet.com/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://sumfaucet.com/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://likeafaucet.com/roll.html", login: "", password: "",regex: "roll.html"},
        {url : "https://likeafaucet.com/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://likeafaucet.com/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://faucetgigs.com",login: "", password: ""},
        {url : "https://faucetgigs.com/?page=ptc",login: "", password: "", regex: "?page=ptc"},
        {url : "https://faucetgigs.com/?page=shortlinks",login: "", password: "", regex: "?page=shortlinks"},

        {url : "https://faucetofbob.xyz/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://faucetofbob.xyz/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://qashbits.com/", login: "", password: ""},
        {url : "https://qashbits.com/ptc.html", login: "", password: "", regex: "ptc.html"},
        {url : "https://qashbits.com/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},

        {url : "https://funcryptofaucet.com/faucet.html", login: "", password: "",regex: "faucet.html"},
        {url : "https://funcryptofaucet.com/ptc.html", login: "", password: "",regex: "ptc.html"},
        {url : "https://funcryptofaucet.com/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},

        {url : "https://faucetsfly.com/roll.html", login: "", password: "",regex: "roll.html"},
        {url : "https://faucetsfly.com/ptc.html", login: "", password: "",regex: "ptc.html"},
        {url : "https://faucetsfly.com/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},

        {url : "https://topadcoin.com/roll.html", login: "", password: "",regex: "roll.html"},
        {url : "https://topadcoin.com/ptc.html", login: "", password: "",regex: "ptc.html"},
        {url : "https://topadcoin.com/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},

        {url : "https://sports4dbtc.com/roll.html", login: "", password: "",regex: "roll.html"},
        {url : "https://sports4dbtc.com/ptc.html", login: "", password: "",regex: "ptc.html"},
        {url : "https://sports4dbtc.com/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},

        {url : "https://coinadster.com/faucet.html",login: "", password: "", regex: "faucet.html"},
        {url : "https://coinadster.com/ptc.html",login: "", password: "", regex: "ptc.html"},
        {url : "https://coinadster.com/shortlink.html",login: "", password: "", regex: "shortlink.html"},

        {url : "https://rushbitcoin.com/ptc.html",login: "", password: "", regex: "ptc.html"},
        {url : "https://rushbitcoin.com/shortlinks.html",login: "", password: "", regex: "shortlinks.html"},

        {url : "https://claimfreecoins.cc/faucet.html",login: "", password: "", regex: "faucet.html"},
        {url : "https://claimfreecoins.cc/ptc.html",login: "", password: "", regex: "ptc.html"},
        {url : "https://claimfreecoins.cc/shortlinks.html",login: "", password: "", regex: "shortlinks.html"},

        {url : "https://macrobits.io/claims.html",login: "", password: "", regex: "claims.html"},
        {url : "https://macrobits.io/ptc.html",login: "", password: "", regex: "ptc.html"},
        {url : "https://macrobits.io/shortlinks.html",login: "", password: "", regex: "shortlinks.html"},

        {url : "https://bitcointricks.com/?page=ptc",login: "", password: "", regex: "?page=ptc"},
        {url : "https://bitcointricks.com/?page=shortlinks",login: "", password: "", regex: "?page=shortlinks"},

        {url : "https://best-shopme.com/roll.html",login: "", password: "", regex: "roll.html"},
        {url : "https://best-shopme.com/ptc.html",login: "", password: "", regex: "ptc.html"},
        {url : "https://best-shopme.com/shortlinks.html",login: "", password: "", regex: "shortlinks.html"},

        {url : "https://grab.tc/faucet.html", login: "", password: "", regex: "faucet.html"},
        {url : "https://grab.tc/?page=ptc", login: "", password: "", regex: "?page=ptc"},
        {url : "https://grab.tc/?page=shortlinks", login: "", password: "", regex: "?page=shortlinks"},


        // Below are the websites which were working once but have been stopped, if the websites are up you may uncomment and use them
        // {url : "https://vsl.one/", login: "", password: ""},
        // {url : "https://probux.org/roll.html", login: "", password: "",regex: "roll.html"},
        // {url : "https://probux.org/ptc.html", login: "", password: "",regex: "ptc.html"},
        // {url : "https://probux.org/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},
        // {url : "https://bitdaddy.cash/", login: "", password: ""},
        // {url : "https://bitdaddy.cash/ptc.html", login: "", password: "", regex: "ptc.html"},
        // {url : "https://bitdaddy.cash/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},
        // {url : "https://cashmine.online",login: "", password: ""},
        // {url : "https://cashmine.online/?page=ptc",login: "", password: "", regex: "?page=ptc"},
        // {url : "https://cashmine.online/?page=shortlinks",login: "", password: "", regex: "?page=shortlinks"},
        // {url : "https://ptchub.xyz/", login: "", password: ""},
        // {url : "https://ptchub.xyz/ptc.html", login: "", password: "", regex: "ptc.html"},
        // {url : "https://ptchub.xyz/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},
        // {url : "https://nevcoins.club/claim.html", login: "", password: "",regex: "claim.html"},
        // {url : "https://nevcoins.club/ptc.html", login: "", password: "",regex: "ptc.html"},
        // {url : "https://nevcoins.club/shortlinks.html", login: "", password: "",regex: "shortlinks.html"},
        // {url : "https://claimlite.club/", login: "", password: ""},
        // {url : "https://claimlite.club/ptc.html", login: "", password: "", regex: "ptc.html"},
        // {url : "https://claimlite.club/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},
        // {url : "https://claimfreebits.com/?page=faucet", login: "", password: "",regex: "?page=faucet"},
        // {url : "https://claimfreebits.com/ptc.html", login: "", password: "", regex: "ptc.html"},
        // {url : "https://claimfreebits.com/shortlinks.html", login: "", password: "", regex: "shortlinks.html"},
    ];

    // The following are the list of shortlinks which will be considered in shortlinks page
    // You can remove the shortlinks which you do not wish to use or add them
    var SHORTLINKS_HCAPTCHA =["1bit.space","mgnet.xyz","mitly",
                              "dash-free.com","zuba.link","snowurl.com",
                              "adshorti.xyz","earnfacut.xyz","clik.pw",
                              "Try2Link","ouo"];
    var SHORTLINKS_REAPTCHA=["Bidurls","birdurls","OwLink","owllink",
                             "Linksly","Namaidani","illink.net","adbull",
                             "link1s.com","adshort",
                             "pong.pw","rainurl.com","cutp.in","link1s.net",
                             "shortzu.icu","clk.sh","tinygo.co","cashurl.win",
                             "goads.ly","Clksh","CCurl","PingIt","Vshort"
                            ];



    //===================DO NOT EDIT THE CODE BELOW UNLESS YOU KNOW WHAT YOU ARE DOING=========================================



    if(window.name == "IconCaptchaWindow"){
        return;
    }

    if(!ENABLE_SHORTLINKS_HCAPTCHA){
        SHORTLINKS_HCAPTCHA = [];
    }

    if(!ENABLE_SHORTLINKS_RECAPTCHA){
        SHORTLINKS_REAPTCHA = [];
    }

    var SHORTLINKS_LIST = SHORTLINKS_HCAPTCHA.concat(SHORTLINKS_REAPTCHA);



    //Message selectors are for success or failure to move on to the next website
    //Add only domain name in website as mentioned below. Follow the same pattern.
    //Use arrays wherever it is required
    var websiteMap = [

        {website : ["get-bitcoin.net","getdoge.io","dogebits.net"],
         beforeLoginButton: ["a.nav-link.btn.btn-purple.btn-signup.text-white"],
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         defaultButtonSelectors: ["#claimFaucet > a"],
         toggleCaptchaSelector:[".modal-dialog .form-control"],
         toggleCaptchaSelectorIndex: "hcaptcha",
         captchaButtonSubmitSelector: ".btn-rounded.btn-sm.w-30.mb-0",
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger", "#main-container h1"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won", "Sucuri Website Firewall"],
         additionalFunctions: getBitcoinDoge},

        {website : ["claimfreebits.com","funcryptofaucet.com", "macrobits.io","bitcointricks.com", "claimfreecoins.cc", "coinadster.com", "claimbits.net","earnbitmoon.club", "claimbit.com","nevcoins.club"],
         defaultButtonSelectors: ["#claimFaucet > button", "#claymFaucet > button"],
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "recaptcha",
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         loginCaptcha : true,
         captchaButtonSubmitSelector: ["button[type=submit]","#rollFaucet > button", "#captchaModal div.modal-body > div button","button.btn.btn-danger.btn-md.w-100.mt-2"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},

        {website : ["claimlite.club","rushbitcoin.com"],
         defaultButtonSelectors: ["#claimFaucet > button", "#claymFaucet > button"],
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1"],
         toggleCaptchaSelectorIndex: "recaptcha",
         loginCaptcha : true,
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         captchaButtonSubmitSelector: ["button.a[type=button]","button[type=submit]","#rollFaucet > button", "#captchaModal div.modal-body > div button"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},

        {website : ["faucetgigs.com","cashmine.online"],
         defaultButtonSelectors: ["#claimFaucet > button", "#claymFaucet > button"],
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "recaptcha",
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         loginCaptcha : true,
         captchaButtonSubmitSelector: [".btn.btn-danger.btn-md.w-100.mt-2:not([data-toggle])",".btn-danger.btn-md.w-50.mt-2","button[type=submit]",".btn.btn-danger.btn-md.w-100.mt-2"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},

        {website : ["likeafaucet.com"],
         defaultButtonSelectors: ["#claimFaucet > button", "#claymFaucet > button"],
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "recaptcha",
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         loginCaptcha : true,
         captchaButtonSubmitSelector: [".btn.btn-danger.btn-md.w-100.mt-2:not([data-toggle])",".btn-danger.btn-md.w-50.mt-2","button[type=submit]"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},

        {website : ["btccanyon.com","best-shopme.com","ptchub.xyz","faucetofbob.xyz","sumfaucet.com","grab.tc","topadcoin.com","probux.org","sports4dbtc.com","ltchunt.com","qashbits.com","bitdaddy.cash"],
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         loginCaptcha : true,
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "recaptcha",
         captchaButtonSubmitSelector: ["#claimFaucet button","button.btn.btn-danger.btn-md.w-100.mt-2","button[type=submit]","#rollFaucet > button", "#captchaModal div.modal-body > div button"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},

        {website : ["faucetsfly.com"],
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-bs-target='#login-modal']"],
         loginCaptcha : true,
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "recaptcha",
         captchaButtonSubmitSelector: [".claim-btn","#claimFaucet button","button.btn.btn-danger.btn-md.w-100.mt-2","button[type=submit]","#rollFaucet > button", "#captchaModal div.modal-body > div button"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},


        {website : ["vsl.one"],
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         loginCaptcha : true,
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "recaptcha",
         captchaButtonSubmitSelector: ["#claimFaucet button","button.btn.btn-danger.btn-md.w-100.mt-2","button[type=submit]","#rollFaucet > button", "#captchaModal div.modal-body > div button"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: shortlinks,
         timeoutbeforeMovingToNextUrl: 180000},

        {website : ["bitcaps.io"],
         loginSelectors: ["input[type=text]", "input[type=password]", "button[type=submit]"],
         beforeLoginButton: ["[data-target='#loginModal']","a.nav-link.btn.btn-info.text-white"],
         loginCaptcha : false,
         toggleCaptchaSelector:[".form-control.form-control-sm.custom-select.mb-1", "#toggleCaptcha","#toggle22Captcha"],
         toggleCaptchaSelectorIndex: "hcaptcha",
         captchaButtonSubmitSelector: ["#claimFaucet button","button.btn.btn-danger.btn-md.w-100.mt-2","button[type=submit]","#rollFaucet > button", "#captchaModal div.modal-body > div button"],
         allMessageSelectors: [".alert.alert-success",".alert.alert-danger"],
         messagesToCheckBeforeMovingToNextUrl: ["can claim again","you won"],
         additionalFunctions: ptcPage,
         timeoutbeforeMovingToNextUrl: 180000},
    ];

    //HtmlEvents dispatcher
    function triggerEvent(el, type) {
        try{
            var e = document.createEvent('HTMLEvents');
            e.initEvent(type, false, true);
            el.dispatchEvent(e);
        }catch(exception){
            console.log(exception);
        }
    }

    function toggleCaptcha(selector, captchaType){

        if( document.querySelector(selector)){

            const select = document.querySelector(selector);
            const optionTextToSelect = captchaType;

            for (let i = 0; i < select.options.length; i++) {
                const option = select.options[i];
                if (option.text.toLowerCase().includes(optionTextToSelect)) {
                    option.selected = true;
                    break;
                }
            }


            var targetNode = document.querySelector(selector);
            if (targetNode) {
                setTimeout(function() {
                    triggerEvent(targetNode, 'change');
                }, 5000);
            }

        }
    }

    //Check if a string is present in Array
    String.prototype.includesOneOf = function(arrayOfStrings) {

        //If this is not an Array, compare it as a String
        if (!Array.isArray(arrayOfStrings)) {
            return this.toLowerCase().includes(arrayOfStrings.toLowerCase());
        }

        for (var i = 0; i < arrayOfStrings.length; i++) {
            if (this.toLowerCase().includes(arrayOfStrings[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    var websiteDataValues = {};
    var clicked = false;

    //Get selector details from the websiteMap
    for (let value of Object.values(websiteMap)) {
        if(window.location.href.includesOneOf(value.website)){
            websiteDataValues.inputTextSelector= value.inputTextSelector;
            websiteDataValues.inputTextSelectorButton = value.inputTextSelectorButton;
            websiteDataValues.beforeLoginButton = value.beforeLoginButton;
            websiteDataValues.defaultButtonSelectors = value.defaultButtonSelectors;
            websiteDataValues.claimButtonSelector = value.claimButtonSelector;
            websiteDataValues.captchaButtonSubmitSelector = value.captchaButtonSubmitSelector;
            websiteDataValues.loginSelectors = value.loginSelectors;
            websiteDataValues.allMessageSelectors = value.allMessageSelectors;
            websiteDataValues.messagesToCheckBeforeMovingToNextUrl = value.messagesToCheckBeforeMovingToNextUrl;
            websiteDataValues.withdrawPageUrl = value.withdrawPageUrl;
            websiteDataValues.withdrawEnabled = value.withdrawEnabled;
            websiteDataValues.balanceSelector = value.balanceSelector;
            websiteDataValues.withdrawMinAmount = value.withdrawMinAmount;
            websiteDataValues.successMessageSelectors = value.successMessageSelectors;
            websiteDataValues.toggleCaptchaSelector = value.toggleCaptchaSelector;
            websiteDataValues.toggleCaptchaSelectorIndex = value.toggleCaptchaSelectorIndex;
            websiteDataValues.timeoutbeforeMovingToNextUrl = value.timeoutbeforeMovingToNextUrl;
            websiteDataValues.additionalFunctions = value.additionalFunctions;
            websiteDataValues.loginCaptcha = value.loginCaptcha;
            break;
        }
    }


    var login = "";
    var password = "";


    //Identify which coin to input, based on the url input
    //If the URL does not contain the coin, then use the default from the domain name
    var count = 0;
    var addressAssigned = false;
    for (let value of Object.values(websiteData)){
        count = count + 1;
        if(value.url.includes(window.location.hostname) && (window.location.href.includes("/" + value.regex + "/") ||
                                                            window.location.href.includes("/" + value.regex + "-") ||
                                                            window.location.href.endsWith("/" + value.regex) ||
                                                            window.location.href.endsWith(window.location.hostname) ||
                                                            window.location.href.endsWith(window.location.hostname + "/"))){
            websiteDataValues.address = value.address;
            login = value.login;
            password = value.password;
            addressAssigned = true;
            break;
        }
    }

    //Close the window after 120 seconds if check.php is present

    if(window.location.href.includes("check.php")){
        setTimeout(function(){
            window.close();
        },120000);
    }

    // Set the window name for icon captcha websites
    if(window.location.href.includes("nav3.php") || window.location.href.includes("surf.php") || window.location.href.includes("surf2.php")){
        window.name="IconCaptchaWindow";
        if(document.querySelector("#frame") &&document.querySelector("#frame").src.includes("nopage.html")){
            window.close();
        }

        if(document.querySelector(".alert.alert-danger") && document.querySelector(".alert.alert-danger").innerText.includes("Session expired")){
            window.close();
        }

        var interval = setInterval(function(){

            if(document.querySelector(".alert.alert-success") && document.querySelector(".alert.alert-success").innerText.includes("received")){
                window.close();
            }

        },5000);

        return;
    }

    //Get the next Url from the website data map
    async function getNextUrl(){

        //Go to the beginning if the end of the array is reached
        if(count >= websiteData.length){
            count = 0;
        }

        websiteDataValues.nextUrl = websiteData[count].url;
        websiteDataValues.regex = websiteData[count].regex;

        //Ping Test to check if a website is up before proceeding to next url
        // pingTest(websiteDataValues.nextUrl);
    }

    var isNextUrlReachable = true;
    //Get the next Url from the website
    function pingTest(websiteUrl) {
        console.log(websiteUrl);
        GM_xmlhttpRequest({
            method: "GET",
            url: websiteUrl,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            timeout: 20000,
            onload: function(response) {
                //Website is reachable
                isNextUrlReachable = true;
            },
            onerror: function(e) {
                count=count+1;
                getNextUrl();
            },
            ontimeout: function() {
                count=count+1;
                getNextUrl();
            },
        });

    }


    async function delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms))
    }

    var movingToNextUrl = false;
    async function goToNextUrl() {
        if(!movingToNextUrl){
            movingToNextUrl = true;
            getNextUrl();
            while (!isNextUrlReachable) {
                await delay(3000);
            }

            //if( websiteDataValues.regex){
            //  GM_setValue("UrlRegex", websiteDataValues.regex);
            //}
            window.location.href = websiteDataValues.nextUrl;
            movingToNextUrl = true;
        }
    }

    async function goToWithdrawPage() {
        if(!movingToNextUrl){
            movingToNextUrl = true;
            window.location.href = websiteDataValues.withdrawPageUrl;
        }

    }


    //Default Setting: After 120 seconds go to next Url
    var delayBeforeMovingToNextUrl = 120000;
    if(websiteDataValues.timeoutbeforeMovingToNextUrl){
        delayBeforeMovingToNextUrl = websiteDataValues.timeoutbeforeMovingToNextUrl;
    }

    setTimeout(function(){
        goToNextUrl();
    },delayBeforeMovingToNextUrl);


    //Returns true if message selectors are present
    function messageSelectorsPresent(){
        if(websiteDataValues.allMessageSelectors){
            for(var j=0;j<websiteDataValues.allMessageSelectors.length;j++){
                for(var k=0; k< document.querySelectorAll(websiteDataValues.allMessageSelectors[j]).length;k++){
                    if(document.querySelectorAll(websiteDataValues.allMessageSelectors[j])[k] &&
                       (document.querySelectorAll(websiteDataValues.allMessageSelectors[j])[k].innerText.includesOneOf(websiteDataValues.messagesToCheckBeforeMovingToNextUrl) ||
                        (document.querySelectorAll(websiteDataValues.allMessageSelectors[j])[k].value &&
                         document.querySelectorAll(websiteDataValues.allMessageSelectors[j])[k].value.includesOneOf(websiteDataValues.messagesToCheckBeforeMovingToNextUrl)))){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    //Returns true if message selectors are present
    function successMessageSelectorsPresent(){
        if(websiteDataValues.successMessageSelectors){
            for(var j=0;j<websiteDataValues.successMessageSelectors.length;j++){
                for(var k=0; k< document.querySelectorAll(websiteDataValues.successMessageSelectors[j]).length;k++){
                    if(document.querySelectorAll(websiteDataValues.successMessageSelectors[j])[k] && document.querySelectorAll(websiteDataValues.successMessageSelectors[j])[k].innerText.includesOneOf(websiteDataValues.messagesToCheckBeforeMovingToNextUrl)){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    function getRGBFromData(data){
        var hashMap = new Map();
        var maxRGB;
        var maxCount = 0;
        for(let i=0;i <data.length;i=i+4){
            let rgb = data[i].toString() + "," + data[i+1].toString() + "," + data[i+2].toString();
            if(data[i+3] > 127){
                if(hashMap.has(rgb)){
                    hashMap.set(rgb, hashMap.get(rgb)+1)
                    if(maxCount < hashMap.get(rgb)){
                        maxCount = hashMap.get(rgb);
                        maxRGB = [data[i],data[i+1],data[i+2]];
                    }
                }
                else{
                    hashMap.set(rgb, 1)
                }
            }
        }

        return maxRGB;
    }

    function isHidden(el) {
        return (el.offsetParent === null);
    }


    function getElementByText(element) {
        element = element.toLowerCase();

        const inputs = Array.from(document.querySelectorAll('input'));
        const foundInput = inputs.find(el => el.value?.toLowerCase().trim()==element && !isAncestorHidden(el));
        if (foundInput) {
            return foundInput;
        }

        const links = Array.from(document.querySelectorAll('a'));
        const foundLink = links.find(el => el.textContent?.toLowerCase().trim()==element && !isAncestorHidden(el));
        if (foundLink) {
            return foundLink;
        }

        const buttons = Array.from(document.querySelectorAll('button'));
        const foundButton = buttons.find(el => el.textContent?.toLowerCase().trim()==element && !isAncestorHidden(el));
        if (foundButton) {
            return foundButton;
        }

        return false;
    }



    function isElementPresent(element) {
        element = element.toLowerCase();

        const inputs = Array.from(document.querySelectorAll('input'));
        const foundInput = inputs.find(el => el.value?.toLowerCase().trim()==element && !isAncestorHidden(el));
        if (foundInput) {
            return true;
        }

        const links = Array.from(document.querySelectorAll('a'));
        const foundLink = links.find(el => el.textContent?.toLowerCase().trim()==element && !isAncestorHidden(el));
        if (foundLink) {
            return true;
        }

        const buttons = Array.from(document.querySelectorAll('button'));
        const foundButton = buttons.find(el => el.textContent?.toLowerCase().trim()==element && !isAncestorHidden(el));
        if (foundButton) {
            return true;
        }

        return false;
    }

    function getTime(){

        const elements = Array.from(document.querySelectorAll('[class*="fa-clock"]'));
        const foundElement = elements.find(el => el && !isAncestorHidden(el) && isTimePresent(el));
        return Number(foundElement?.parentElement?.innerText);

    }

    function getTimeElement(){

        const elements = Array.from(document.querySelectorAll('[class*="fa-clock"]'));
        const foundElement = elements.find(el => el && !isAncestorHidden(el) && isTimePresent(el));
        let parent = foundElement?.parentElement?.parentElement?.parentElement;
        if(parent){
            const elements = Array.from(parent.querySelectorAll("button"));
            const foundButton = elements.find(el => el.innerText?.toLowerCase().trim()=="visit" && !isAncestorHidden(el));
            if (foundButton) {
                return foundButton;
            }
        }
        return false;

    }


    function isTimePresent(element) {

        if(!Number.isInteger(Number(element?.parentElement?.innerText))){
            return false;
        }

        let parent = element?.parentElement?.parentElement?.parentElement;
        if(parent){
            const elements = Array.from(parent.querySelectorAll('*'));
            const foundButton = elements.find(el => el.innerText?.toLowerCase().trim()=="visit" && !isAncestorHidden(el));
            if (foundButton) {
                return true;
            }

            const foundInput = elements.find(el => el.value?.toLowerCase().trim()=="visit" && !isAncestorHidden(el));
            if (foundInput) {
                return true;
            }

        }
        return false;
    }


    function isAncestorHidden(element) {
        let parent = element;
        while (parent) {
            const display = getComputedStyle(parent).getPropertyValue('display');
            if (display === 'none') {
                return true;
            }
            parent = parent.parentElement;
        }
        return false;
    }




    function ptcPage(){

        if(window.location.href.includes("shortlink")){
            shortlinks();
            return;

        }

        //Check if the faucet considers solving the shortlink quickly
        //This will stop the loop condition
        if(window.location.href.includes("time")){
            goToNextUrl();
            return;
        }


        if((window.location.href.endsWith("ptc") || window.location.href.endsWith("ptc.html") || window.location.href.endsWith("ptc/")
            || window.location.href.endsWith("ptc.html/")) && !(document.querySelector(".website_block .btn.btn-success.btn-sm") || isElementPresent("Visit")) &&
           !(window.name=="IconCaptchaWindow")){
            goToNextUrl();
            return;
        }

        if((window.location.href.endsWith("ptc") || window.location.href.endsWith("ptc.html") || window.location.href.endsWith("ptc/")
            || window.location.href.endsWith("ptc.html/")) && (document.querySelector(".website_block .btn.btn-success.btn-sm") || isElementPresent("Visit")) &&
           !(window.name=="IconCaptchaWindow")){


            var oldfunction = unsafeWindow.open;
            var windowName = "";
            var popUpWindow = "";

            function newFunction(params1, params2) {

                popUpWindow = oldfunction(params1, windowName);
                return popUpWindow;
            };

            unsafeWindow.open = newFunction;

            if (window.performance) {
                if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
                    console.log("window reloaded");
                    let time = 0;
                    time = getTime();

                    if((!time || time ==0) && document.querySelector("div.time") && document.querySelector("div.time").innerText){
                        time = document.querySelector("div.time").innerText;
                        time = time.trim();
                        time = parseInt(time);

                    }

                    var tmpTime = time;

                    if(GM_getValue("waitingTime")){
                        tmpTime = GM_getValue("waitingTime");
                    }

                    setTimeout(function(){
                        GM_setValue("waitingTime", time);

                        if(isElementPresent("visit")){

                            let element = getTimeElement();
                            if(element && element.getAttribute("onclick")){

                                if( GM_getValue("ptcVisited") &&
                                   GM_getValue("ptcVisited") == element.getAttribute("onclick")){
                                    console.log("Website Already Visited or has a problem");
                                    goToNextUrl();
                                    return;
                                }

                                GM_setValue("ptcVisited", element.getAttribute("onclick"));
                            }

                            element?.click();
                        }
                    },tmpTime*1000 + 20000);

                } else {
                    var ptcCount = document.querySelectorAll(".website_block .btn.btn-success.btn-sm").length;
                    var count = 1;
                    let time = 0;
                    time = getTime();

                    if((!time || time ==0) && document.querySelector("div.time") && document.querySelector("div.time").innerText){
                        time = document.querySelector("div.time").innerText;
                        time = time.trim();
                        time = parseInt(time);

                    }

                    GM_setValue("waitingTime", time);

                    count =0;

                    setInterval(function(){

                        time = getTime();
                        if((!time || time ==0) && document.querySelector("div.time") && document.querySelector("div.time").innerText){
                            time = document.querySelector("div.time").innerText;
                            time = time.trim();
                            time = parseInt(time);

                        }

                        let element = getTimeElement();

                        if((!popUpWindow || (popUpWindow && popUpWindow.closed))){

                            if(element){

                                if(element && element.getAttribute("onclick")){
                                    if( GM_getValue("ptcVisited") &&
                                       GM_getValue("ptcVisited") == element.getAttribute("onclick")){
                                        console.log("Website Already Visited or has a problem");
                                        goToNextUrl();
                                        return;
                                    }

                                    GM_setValue("ptcVisited", element.getAttribute("onclick"));
                                }

                                element?.click();
                            }
                            count++;
                        }
                    },10000);
                }
            }

        }

    }

    function getBitcoinDoge(){

        if(window.location.href.includes("shortlink")){
            shortlinks();
            return;

        }


        if(window.location.href.includes("read.html") && !document.querySelector(".btn.btn-md.w-100.mt-1")){

            goToNextUrl();
            return;
        }
        if(window.location.href.includes("read.html") && document.querySelector(".btn.btn-md.w-100.mt-1")){


            var oldfunction = unsafeWindow.open;
            var windowName = "";
            var popUpWindow = "";

            function newFunction(params1, params2) {

                popUpWindow = oldfunction(params1, windowName);
                return popUpWindow;
            };

            unsafeWindow.open = newFunction;



            if (window.performance) {
                if (performance.navigation.type == performance.navigation.TYPE_RELOAD) {
                    console.log("window reloaded");
                    let time = 0;
                    if(document.querySelector("div.time") && document.querySelector("div.time").innerText){
                        time = document.querySelector("div.time").innerText;
                        time = time.trim();
                        time = parseInt(time);

                    }

                    var tmpTime = time;

                    if(GM_getValue("waitingTime")){
                        tmpTime = GM_getValue("waitingTime");
                    }

                    setTimeout(function(){
                        GM_setValue("waitingTime", time);
                        if(document.querySelector(".btn.btn-md.w-100.mt-1") && !isHidden(document.querySelector(".btn.btn-md.w-100.mt-1"))){
                            document.querySelector(".btn.btn-md.w-100.mt-1").click();
                        }
                    },tmpTime*1000 + 20000);

                } else {


                    let time = 0;
                    var ptcCount = document.querySelectorAll(".btn.btn-md.w-100.mt-1").length;
                    var count = 1;

                    if(document.querySelector("div.time") && document.querySelector("div.time").innerText){
                        time = document.querySelector("div.time").innerText;
                        time = time.trim();
                        time = parseInt(time);
                    }
                    GM_setValue("waitingTime", time);

                    count =0;

                    setInterval(function(){

                        if(document.querySelector("div.time") && document.querySelector("div.time").innerText){
                            time = document.querySelector("div.time").innerText;
                            time = time.trim();
                            time = parseInt(time);
                        }

                        if((!popUpWindow || (popUpWindow && popUpWindow.closed)) && count < ptcCount){
                            if(document.querySelectorAll(".btn.btn-md.w-100.mt-1")[count] &&
                               !isHidden(document.querySelectorAll(".btn.btn-md.w-100.mt-1")[count])){
                                document.querySelectorAll(".btn.btn-md.w-100.mt-1")[count].click();
                            }
                            count++;
                        }
                    },10000);
                }
            }

            return;
        }


        try{
            var j =0;
            var leastDifference = 10000;
            if(document.querySelector("div.modal-body img") && document.querySelectorAll("table > tbody > tr img").length > 3){
                let image = document.querySelector("div.modal-body img");
                let c = document.createElement("canvas");
                c.width = image.width;
                c.height = image.height;
                var ctx = c.getContext("2d");
                ctx.drawImage(image, 0, 0);
                var imageData = ctx.getImageData(0, 0, c.width, c.height);
                var data = imageData.data;
                var questionRGB = getRGBFromData(data);

                //compare with the answers
                for(let i=0;i< document.querySelectorAll("table > tbody > tr img").length;i++){
                    let image = document.querySelectorAll("table > tbody > tr img")[i];
                    let canva = document.createElement("canvas");
                    canva.width = image.width;
                    canva.height = image.height;
                    let canvatx = canva.getContext("2d");
                    canvatx.drawImage(image, 0, 0);

                    // canvatx.fillStyle = document.querySelectorAll("button[class='btn btn-lg']")[i].style.backgroundColor;
                    // canvatx.fillRect(0, 0,canva.width,canva.height);

                    let imageData = canvatx.getImageData(0, 0,canva.width,canva.height);
                    let rgb = getRGBFromData(imageData.data);

                    if(Math.abs(questionRGB[0]-rgb[0]) + Math.abs(questionRGB[1]-rgb[1]) + Math.abs(questionRGB[2]-rgb[2]) < leastDifference){
                        leastDifference = Math.abs(questionRGB[0]-rgb[0]) + Math.abs(questionRGB[1]-rgb[1]) + Math.abs(questionRGB[2]-rgb[2]);
                        j = i;
                    }

                    if(Math.abs(questionRGB[0]-rgb[0])<= 30 && Math.abs(questionRGB[1]-rgb[1]) <= 30 && Math.abs(questionRGB[2]-rgb[2]) <= 30){
                        break;
                    }
                }

                // console.log("Closest Matching Colour");
                // console.log(document.querySelectorAll("table > tbody > tr img")[j]);
                document.querySelectorAll("table > tbody > tr img")[j].click();

                setTimeout(function(){
                    if(document.querySelector("#NXReportButton")){
                        document.querySelector("#NXReportButton").click();
                    }
                    setTimeout(function(){

                        toggleCaptcha(".form-control.form-control-sm.custom-select.mb-1","hcaptcha");

                        for(var hc=0; hc < document.querySelectorAll("iframe").length; hc++){
                            if(document.querySelectorAll("iframe")[hc] &&
                               document.querySelectorAll("iframe")[hc].hasAttribute("data-hcaptcha-response")){
                                return;
                            }
                        }

                        if(document.querySelector(".btn-rounded.btn-sm.w-30.mb-0")){
                            document.querySelector(".btn-rounded.btn-sm.w-30.mb-0").click();
                        }
                        setTimeout(function(){
                            if(messageSelectorsPresent()){
                                goToNextUrl();
                            }
                        },5000);
                    },5000);
                },5000);
            }


        }catch(e){
            //console.log(e);
        }
    }


    function shortlinks(){
        var clicked = false;

        var oldfunction = unsafeWindow.open;
        var windowName = "";
        var popUpWindow = "";

        function newFunction(params1, params2) {
            window.location.href = params1;
        };

        unsafeWindow.open = newFunction;
        let buttons = document.querySelectorAll('button');
        loopB:
        for(let i=0; i< buttons.length;i++){
            if(buttons[i]?.innerText.toLowerCase().trim() == "visit" && !isAncestorHidden(buttons[i])){

                for(let j=0; j<SHORTLINKS_LIST.length;j++){
                    if(buttons[i].parentElement?.innerText.toLowerCase().includes(SHORTLINKS_LIST[j].toLowerCase()) ||
                       buttons[i].parentElement?.parentElement?.innerText.toLowerCase().includes(SHORTLINKS_LIST[j].toLowerCase())){
                        buttons[i]?.click();
                        clicked = true;
                        break loopB;
                    }
                }
            }

        }


        if(!clicked){
            goToNextUrl();
        }

    }


    if(ENABLE_NEXT_BUTTON){

        var node = document.createElement ('div');
        node.setAttribute ('class', 'floatbuttonabc nextabc');


        node.innerHTML = '<p>Next</p>';
        document.body.appendChild (node);

        document.querySelector(".floatbuttonabc").addEventListener (
            "click", goToNextUrl, false
        );


        GM_addStyle ( `

.floatbuttonabc {
  position: fixed;
  right: -77px;
  top: 270px;
  transition: all 0.2s ease-in 0s;//this is the key attribute
  z-index: 9999;
  cursor: pointer;
}

.floatbuttonabc:hover {
  right: -7px;//hide it by pushing it off the screen
}

.nextabc {
  position: fixed;
  width: 20%;
}

.nextabc p {
  padding: 8px;
  margin-bottom: 8px;
  background-color: #33b5e5;
  color: #ffffff;
}

.nextabc p:hover {
  background-color: #0099cc;
}


` );

    }

    function checkLoginSelectors(){

        if(websiteDataValues.loginSelectors){
            //Check if all login selectors are present
            let count =0;
            for(let i=0; i< websiteDataValues.loginSelectors.length; i++){
                if(document.querySelector(websiteDataValues.loginSelectors[i])){
                    count++;
                }

            }

            if(count == websiteDataValues.loginSelectors.length){
                //Checkboxes
                for(let i=0; i<document.querySelectorAll("label.custom-control-label").length;i++){
                    document.querySelectorAll("label.custom-control-label")[i].click();
                }


                if(login.length > 0 && password.length > 0){

                    //Input Login
                    document.querySelector(websiteDataValues.loginSelectors[0]).value = login;

                    //Input Password
                    document.querySelector(websiteDataValues.loginSelectors[1]).value = password;

                    //Click Login Button (No Captcha before login button)
                    if(!websiteDataValues.loginCaptcha){
                        movingToNextUrl = true;
                        document.querySelector(websiteDataValues.loginSelectors[2]).click();
                    }
                }

            }

        }

    }

    function solveCaptcha(){
        //Click the form button after solving captcha
        //Works for both recaptcha and hcaptcha
        var clicked = false;
        var captchaInterval = setInterval(function(){

            if(document.querySelector("div.iconcaptcha-modal__body-title") &&
               document.querySelector("div.iconcaptcha-modal__body-title").innerText.includes("VERIFICATION COMPLETE")){
                if(websiteDataValues.captchaButtonSubmitSelector){
                    document.querySelector(websiteDataValues.captchaButtonSubmitSelector).click();
                }
                clicked = true;

                clearInterval(captchaInterval);
                setTimeout(function(){
                    if(messageSelectorsPresent()){
                        goToNextUrl();
                    }
                },5000);
                return;
            }

            try{
                if(!clicked && grecaptcha && grecaptcha.getResponse().length > 0 || document.querySelector(".g-recaptcha").getAttribute("value").length > 0){
                    if(websiteDataValues.captchaButtonSubmitSelector){

                        document.querySelector(websiteDataValues.captchaButtonSubmitSelector).click();
                    }
                    clicked = true;

                    clearInterval(captchaInterval);
                    setTimeout(function(){
                        if(messageSelectorsPresent()){
                            goToNextUrl();
                        }
                    },5000);
                }
            }catch(e){

            }

            for(var hc=0; hc < document.querySelectorAll("iframe").length; hc++){
                if(! clicked && document.querySelectorAll("iframe")[hc] &&
                   document.querySelectorAll("iframe")[hc].getAttribute("data-hcaptcha-response") &&
                   document.querySelectorAll("iframe")[hc].getAttribute("data-hcaptcha-response").length > 0) {

                    if(websiteDataValues.captchaButtonSubmitSelector){

                        document.querySelector(websiteDataValues.captchaButtonSubmitSelector).click();
                    }
                    clicked = true;

                    clearInterval(captchaInterval);
                    setTimeout(function(){
                        if(messageSelectorsPresent()){
                            goToNextUrl();
                        }
                    },5000);
                }
            }

        },5000);


    }


    setTimeout(function(){

        var isBeforeLoginSelectorPresent = false;
        if(!movingToNextUrl && websiteDataValues.beforeLoginButton){
            for(let i=0;i<websiteDataValues.beforeLoginButton.length ;i++){
                if(document.querySelector(websiteDataValues.beforeLoginButton[i])){
                    triggerEvent(document.querySelector(websiteDataValues.beforeLoginButton[i]), 'mousedown');
                    triggerEvent(document.querySelector(websiteDataValues.beforeLoginButton[i]), 'mouseup');
                    document.querySelector(websiteDataValues.beforeLoginButton[i]).click();
                    isBeforeLoginSelectorPresent = true;
                    break;
                }
            }
        }


        checkLoginSelectors();
        if(isBeforeLoginSelectorPresent){
            solveCaptcha();
            return;
        }

        if(websiteDataValues.additionalFunctions){
            websiteDataValues.additionalFunctions();
        }


        if(websiteDataValues.withdrawEnabled){
            if(websiteDataValues.balanceSelector && document.querySelector(websiteDataValues.balanceSelector)){
                var currentBalance = document.querySelector(websiteDataValues.balanceSelector).innerText;
                if(currentBalance > websiteDataValues.withdrawMinAmount && !window.location.href.includes(websiteDataValues.withdrawPageUrl)) {
                    goToWithdrawPage();
                }

            }else{
                if(successMessageSelectorsPresent()){
                    goToWithdrawPage();
                }
            }
        }

        //Look for all the default messages or errors before proceeding to next url
        //For other languages difference in the length of the strings can be compared or visibility of the style element
        if(!movingToNextUrl && messageSelectorsPresent()){
            goToNextUrl();
        }
        //Check for all the default button selectors and click
        //This will only click the first selector found, so mention the selectors with parent element wherever required
        if(!movingToNextUrl && websiteDataValues.defaultButtonSelectors){
            for(let i=0;i<websiteDataValues.defaultButtonSelectors.length ;i++){
                if(document.querySelector(websiteDataValues.defaultButtonSelectors[i])){
                    triggerEvent(document.querySelector(websiteDataValues.defaultButtonSelectors[i]), 'mousedown');
                    triggerEvent(document.querySelector(websiteDataValues.defaultButtonSelectors[i]), 'mouseup');
                    document.querySelector(websiteDataValues.defaultButtonSelectors[i]).click();
                    break;
                }
            }
        }

        //  if(!movingToNextUrl && websiteDataValues.toggleCaptchaSelector && Number.isInteger(websiteDataValues.toggleCaptchaSelectorIndex)){
        if(!movingToNextUrl && websiteDataValues.toggleCaptchaSelector && websiteDataValues.toggleCaptchaSelectorIndex){
            toggleCaptcha(websiteDataValues.toggleCaptchaSelector,websiteDataValues.toggleCaptchaSelectorIndex);
        }


        //Input the address and click the login button
        if(!movingToNextUrl && document.querySelector(websiteDataValues.inputTextSelector)){
            document.querySelector(websiteDataValues.inputTextSelector).value = websiteDataValues.address;
            setTimeout(function(){
                if(websiteDataValues.inputTextSelectorButton && document.querySelector(websiteDataValues.inputTextSelectorButton)){
                    document.querySelector(websiteDataValues.inputTextSelectorButton).click();
                }

            },5000);
        }

        solveCaptcha();

    },10000);




})();