// ==UserScript==
// @name        THE ULTIMATE SCRIPT GPT 4o
// @namespace   auto.claim.faucet
// @description https://keran.co/?ref=35176
// @author      MrBug
// @version     0.1
// @icon        https://www.google.com/s2/favicons?sz=64&domain=keran.co
// @grant       window.close
// ==/UserScript==

(function(){
    'use strict';

    var email = 'seuemail@hosteDoEmail.com'; // Type here your e-mail address
    var intervalclaim = 10 // Don't change it

    function onDocumentReady(fn) {
        if (document.readyState != "loading") {
            fn();
        } else {
            document.addEventListener("DOMContentLoaded", fn);
        }
    }

    onDocumentReady(function(){

        let check_address = 'https://keran.co';
        function isCaptchaChecked() {
            return (
                (grecaptcha && grecaptcha.getResponse().length > 0)
            );
        }


        let login = setInterval (function(){
            let card_md = document.querySelector("#myModal.is-active")
            let emailfield = document.querySelector("input[type='email']")
            let button = document.querySelector("button[type='submit']")
            if(card_md && emailfield && emailfield.value !== email){
                emailfield.value = email;
            }
            if(emailfield.value == email && isCaptchaChecked()){
                button.click();
                clearInterval(login);
            }
        },5000)

        if(window.location.href.includes('captha')){
            let claim = setInterval(function (){
                let button = document.querySelector("button[data-target='#myModal']:not([disabled])")
                let button2 = document.querySelector("button[type='submit']")
                if(button){
                    button.click();
                }
                if(button2 && isCaptchaChecked()){
                    setTimeout(function() { window.location.reload() }, 50000)
                    button2.click();
                    clearInterval(claim);
                }

            },5000)

            let claim2 = setInterval(function (){
                let turnstile = document.querySelector("input[name='cf-turnstile-response']")
                let button = document.querySelector("button[data-target='#myModal']:not([disabled])")
                let button2 = document.querySelector("button[type='submit']")
                if(button){
                    button.click();
                }
                if(button2 && turnstile && turnstile.value.length > 0){
                    setTimeout(function() { window.location.reload() }, 60000)
                    button2.click();
                    clearInterval(claim2);
                }

            },5000)
        }



if(window.location.href.includes('faucet')){
    let lastClickedIndex = localStorage.getItem('lastClickedIndex') || -1; // Obter o último índice do localStorage, se não existir, use -1
    let buttons = document.querySelectorAll("button[type='submit']:not([disabled])");

    setTimeout(function(){
        if (lastClickedIndex == -1) {
            // Se for a primeira vez, clique no primeiro botão disponível
            if (buttons.length > 0) {
                buttons[0].click();
                lastClickedIndex = 0;
                localStorage.setItem('lastClickedIndex', lastClickedIndex); // Salvar o novo índice no localStorage
            }
        } else {
            // Clique no próximo botão disponível, se houver
            let nextIndex = (parseInt(lastClickedIndex) + 1) % buttons.length;
            if (nextIndex != lastClickedIndex) {
                buttons[nextIndex].click();
                lastClickedIndex = nextIndex;
                localStorage.setItem('lastClickedIndex', lastClickedIndex); // Salvar o novo índice no localStorage
            }
        }

        setTimeout(function(){window.location.reload()}, 60000);
    }, 5000);

    setTimeout(function refresh() {
        window.location.reload();
    }, intervalclaim*60000 + Math.floor(Math.random()*60000) + 20000);
}



        if(window.location.href.includes('dashboard')){
            setTimeout(function(){
                location.href= 'faucet.php'
            },5000)
        }

        if(window.location.href == (check_address) || window.location.href == (check_address + '/') || window.location.href == (check_address + '/index.php')){
            setTimeout(function(){
                if(location.search !== '?ref=35176'){
                    location.search = '?ref=35176'
                }
            },2000)
        }

        if(location.search == '?ref=35176'){
            setTimeout(function(){
                let button = document.querySelector('button[data-target="#myModal"]');
                if(button){
                    button.click();
                }
                setTimeout(function(){window.location.reload()},60000)
            },3000)
        }

        setTimeout(function(){
            let alertMsg = document.querySelector("div.message-body")
            if(alertMsg && alertMsg.innerText.includes("was sent")){
                location.reload()
            }
        },5000)

    });


})();