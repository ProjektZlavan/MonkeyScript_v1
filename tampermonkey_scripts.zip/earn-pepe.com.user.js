// ==UserScript==
// @name         earn-pepe.com
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Faucet claim
// @author       Gysof
// @match        https://earn-pepe.com/*
// @icon         https://earn-pepe.com/assets/upload/favicon/apple-touch-icon.png
// @grant        none
// @criado       2024-05-15
// @modificado   2024-05-15
// @downloadURL https://update.greasyfork.org/scripts/495067/earn-pepecom.user.js
// @updateURL https://update.greasyfork.org/scripts/495067/earn-pepecom.meta.js
// ==/UserScript==

// Updates here - https://sharetext.me/9yxit3sucs

// Register here - https://earn-pepe.com/?r=100330
// You will need Cloudflare Turnstile solver
// Editar email e pass linha 23 - 24
// Reivindicar faucet a cada 1 minuto

(function() {
    'use strict';

    // Editar email e senha
    const email = "Your@Email"; // Substitua com seu email
    const senha = "YouPassword"; // Substitua com sua senha

    function GyRd() {
        if (window.location.pathname === '/' || window.location.pathname === '/index') {
            window.location.href = 'https://earn-pepe.com/login';
        } else if (window.location.pathname === '/dashboard') {
            window.location.href = 'https://earn-pepe.com/claim';
        }
    }

    function GyWe(selector, callback) {
        const observer = new MutationObserver((mutations, me) => {
            const element = document.querySelector(selector);
            if (element) {
                callback(element);
                me.disconnect();
            }
        });

        observer.observe(document, {
            childList: true,
            subtree: true
        });
    }

    async function GyCc() {
        let captchaInput;
        while (!captchaInput || captchaInput.value.length === 0) {
            captchaInput = document.querySelector('input[name="cf-turnstile-response"]');
            await new Promise(resolve => setTimeout(resolve, 100));
        }
    }

    async function GyCr() {
        await new Promise(resolve => setTimeout(resolve, 6000));
        const rewardButton = document.querySelector('button.claim-button.btn.btn-lg.btn-primary.mb-8');
        if (rewardButton) {
            rewardButton.click();
        }
    }

    function GyRl() {
        setInterval(() => {
            window.location.reload();
        }, 30000);
    }

    function GyLf() {
        GyWe('#email', (emailInput) => {
            emailInput.value = email;

            const passwordInput = document.querySelector('input[name="password"]');
            if (passwordInput) {
                passwordInput.value = senha;

                const agreeCheckbox = document.querySelector('#agree');
                if (agreeCheckbox) {
                    agreeCheckbox.checked = true;

                    GyCc().then(() => {
                        document.querySelector('button[type="submit"]').click();
                    });
                }
            }
        });
    }

    function GyBg() {
        if (document.hidden) {
            document.title = "earn-pepe - Active";
            window.focus();
        }
    }

    function main() {
        GyRd();

        if (window.location.pathname === '/login') {
            GyLf();
        }

        if (window.location.pathname === '/claim') {
            GyRl();
            GyWe('button.claim-button.btn.btn-lg.btn-primary.mb-8', async (rewardButton) => {
                await GyCc();
                GyCr();
            });
        }
    }

    main();

    GyBg();
    document.addEventListener('DOMContentLoaded', GyBg);
    document.addEventListener('visibilitychange', GyBg);
    window.addEventListener('focus', GyBg);
    setInterval(GyBg, 1000);

})();
